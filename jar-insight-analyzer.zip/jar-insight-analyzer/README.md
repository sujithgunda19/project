# Jar Insight Analyzer

This Java project scans a given JAR file to extract annotations used in classes.

## Usage

### Build
```
mvn clean package
```

### Run
```
java -jar target/jar-insight-analyzer.jar your.jar --format=json
```

Supported formats:
- `plain` (default)
- `json`

## Output
- `annotation-report.txt` or `annotation-report.json` depending on the format.
package com.insight.analyzer.scanner;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.insight.analyzer.model.ClassAnnotationMeta;

public class JarInsightEngineTest {

    @Test
    public void testAnalyzeWithValidJar() throws Exception {
        // Create a temporary directory for our test files
        Path tempDir = Files.createTempDirectory("jar-test");
        try {
            // 1. Create a real annotated Java source file
            File javaFile = new File(tempDir.toFile(), "TestClass.java");
            Files.writeString(javaFile.toPath(), """
                package com.example;
                
                @Deprecated
                public class TestClass {
                    @Override
                    public String toString() {
                        return "Test";
                    }
                }
                """);

            // 2. Compile the Java file
            JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
            int compilationResult = compiler.run(null, null, null, javaFile.getAbsolutePath());
            assertTrue(compilationResult == 0, "Compilation should succeed");

            // 3. Create a JAR file with the compiled class
            File jarFile = new File(tempDir.toFile(), "test.jar");
            try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(jarFile));
                FileInputStream fis = new FileInputStream(new File(tempDir.toFile(), "TestClass.class"))) {
                
                JarEntry entry = new JarEntry("com/example/TestClass.class");
                jos.putNextEntry(entry);
                
                byte[] buffer = new byte[1024];
                int length;
                while ((length = fis.read(buffer)) > 0) {
                    jos.write(buffer, 0, length);
                }
                jos.closeEntry();
            }

            // 4. Test the analyzer
            JarInsightEngine engine = new JarInsightEngine();
            List<ClassAnnotationMeta> results = engine.analyze(jarFile.getAbsolutePath());
            
            // 5. Verify results
            assertFalse(results.isEmpty(), "Results should not be empty for a JAR with annotations");
            
            boolean foundTestClass = results.stream()
                .anyMatch(meta -> meta.getClassName().contains("TestClass"));
            assertTrue(foundTestClass, "Should find our test class");
            
            ClassAnnotationMeta testClassMeta = results.get(0);
            assertFalse(testClassMeta.getClassAnnotations().isEmpty(), 
                "Test class should have annotations");
            assertTrue(testClassMeta.getClassAnnotations().contains("@Deprecated"),
                "Should find @Deprecated annotation");

        } finally {
            // Clean up
            deleteDirectory(tempDir.toFile());
        }
    }

    @Test
    public void testAnalyzeWithNonExistentJar() {
        JarInsightEngine engine = new JarInsightEngine();
        List<ClassAnnotationMeta> results = engine.analyze("nonexistent.jar");
        assertTrue(results.isEmpty(), "Should return empty list for non-existent JAR");
    }

    @Test
    public void testAnalyzeWithEmptyJar(@TempDir Path tempDir) throws Exception {
        Path emptyJar = tempDir.resolve("empty.jar");
        Files.createFile(emptyJar);
        
        JarInsightEngine engine = new JarInsightEngine();
        List<ClassAnnotationMeta> results = engine.analyze(emptyJar.toString());
        assertTrue(results.isEmpty(), "Should return empty list for empty JAR");
    }

    // Helper method to delete directory recursively
    private void deleteDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        directory.delete();
    }
}
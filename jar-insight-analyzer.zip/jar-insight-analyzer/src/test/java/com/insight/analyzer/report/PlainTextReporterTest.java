package com.insight.analyzer.report;
//Add these imports at the top of each test class
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.insight.analyzer.model.ClassAnnotationMeta;
import com.insight.analyzer.report.PlainTextReporter;

public class PlainTextReporterTest {

    @Test
    public void testWriteReportWithValidData() throws Exception {
        // Setup
        PlainTextReporter reporter = new PlainTextReporter();
        Map<String, List<String>> methodAnnotations = new HashMap<>();
        methodAnnotations.put("testMethod", Arrays.asList("@GetMapping", "@RequestMapping"));
        ClassAnnotationMeta meta = new ClassAnnotationMeta(
            "com.example.TestClass", 
            Arrays.asList("@Service", "@Transactional"), 
            methodAnnotations
        );
        
        // Execute
        reporter.writeReport(Collections.singletonList(meta));
        
        // Verify
        File outputFile = new File("annotation-report.txt");
        assertTrue(outputFile.exists());
        assertTrue(outputFile.length() > 0);
        
        // Verify content structure
        String content = new String(java.nio.file.Files.readAllBytes(outputFile.toPath()));
        assertTrue(content.contains("com.example.TestClass"));
        assertTrue(content.contains("[Class] -> @Service, @Transactional"));
        assertTrue(content.contains("method testMethod() -> @GetMapping, @RequestMapping"));
        
        outputFile.delete(); // Clean up
    }

    @Test
    public void testWriteReportWithEmptyList() throws Exception {
        // Setup
        PlainTextReporter reporter = new PlainTextReporter();
        
        // Execute
        reporter.writeReport(Collections.emptyList());
        
        // Verify
        File outputFile = new File("annotation-report.txt");
        assertTrue(outputFile.exists());
        assertEquals(0, outputFile.length());
        outputFile.delete(); // Clean up
    }
}
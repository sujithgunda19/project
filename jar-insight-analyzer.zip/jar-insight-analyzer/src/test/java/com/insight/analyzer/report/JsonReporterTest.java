package com.insight.analyzer.report;

//Add these imports at the top of each test class
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.insight.analyzer.model.ClassAnnotationMeta;

public class JsonReporterTest {

	 @Test
	    public void testWriteReportWithEmptyList() throws Exception {
	    	JsonReporter reporter = new JsonReporter();
	        reporter.writeReport(Collections.emptyList());
	        
	        File outputFile = new File("annotation-report.json");
	        assertTrue(outputFile.exists());
	        
	        // Verify content is empty array
	        String content = new String(Files.readAllBytes(outputFile.toPath()));
	        assertEquals("[ ]", content.trim());
	        
	        outputFile.delete(); // Clean up
	    }
	 
    @Test
    public void testWriteReportWithValidData() throws Exception {
        // Setup
        JsonReporter reporter = new JsonReporter();
        Map<String, List<String>> methodAnnotations = new HashMap<>();
        methodAnnotations.put("testMethod", Arrays.asList("@GetMapping", "@RequestMapping"));
        ClassAnnotationMeta meta = new ClassAnnotationMeta(
            "com.example.TestClass", 
            Arrays.asList("@Service", "@Transactional"), 
            methodAnnotations
        );
        
        // Execute
        reporter.writeReport(Collections.singletonList(meta));
        
        // Verify
        File outputFile = new File("annotation-report.json");
        assertTrue(outputFile.exists());
        assertTrue(outputFile.length() > 0);
        outputFile.delete(); // Clean up
    }

   
}
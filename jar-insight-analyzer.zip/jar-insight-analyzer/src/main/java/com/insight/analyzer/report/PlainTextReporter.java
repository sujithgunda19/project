package com.insight.analyzer.report;

import com.insight.analyzer.config.AnalyzerConfigConstants;
import com.insight.analyzer.model.ClassAnnotationMeta;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Implementation of the {@link Reporter} interface that generates a plain text report.
 * <p>
 * This reporter writes the class name, class-level annotations,
 * and method-level annotations to a human-readable text file.
 * </p>
 *
 * <h3>Output:</h3>
 * The report is saved to the path specified by {@link AnalyzerConfigConstants#OUTPUT_FILE_TXT}.
 *
 * <h3>Format Example:</h3>
 * <pre>
 * com.example.MyService
 *   [Class] -> @Service, @Transactional
 *   method getUser() -> @GetMapping, @Transactional
 *   method saveUser() -> @PostMapping
 * </pre>
 *
 * <h3>Design Goals:</h3>
 * - Follows Open/Closed Principle: easily extendable for other formats
 * - Efficient I/O using try-with-resources
 */
public class PlainTextReporter implements Reporter {

    /**
     * Writes the annotation analysis result to a plain text file.
     *
     * @param data List of {@link ClassAnnotationMeta} entries representing analysis results.
     */
    @Override
    public void writeReport(List<ClassAnnotationMeta> data) {
        // Use try-with-resources to ensure the writer is closed automatically
        try (FileWriter writer = new FileWriter(AnalyzerConfigConstants.OUTPUT_FILE_TXT)) {

            // Iterate over each analyzed class metadata
            for (ClassAnnotationMeta entry : data) {
                // Write the class name
                writer.write(entry.getClassName() + "\n");

                // Write class-level annotations if any
                if (!entry.getClassAnnotations().isEmpty()) {
                    writer.write("  [Class] -> " + String.join(", ", entry.getClassAnnotations()) + "\n");
                }

                // Write method-level annotations
                for (Map.Entry<String, List<String>> methodEntry : entry.getMethodAnnotations().entrySet()) {
                    writer.write("  method " + methodEntry.getKey() + "() -> " +
                            String.join(", ", methodEntry.getValue()) + "\n");
                }

                // Separate entries with a newline for readability
                writer.write("\n");
            }

            // Notify user of successful write
            System.out.println("Plain text report generated successfully " + AnalyzerConfigConstants.OUTPUT_FILE_TXT);
        } catch (IOException e) {
            // Handle any I/O error gracefully
            System.err.println("******Error in generating  report in plain text format: " + e.getMessage());
        }
    }
}

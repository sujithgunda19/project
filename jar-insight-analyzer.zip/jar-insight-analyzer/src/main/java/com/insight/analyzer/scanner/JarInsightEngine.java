package com.insight.analyzer.scanner;

import com.insight.analyzer.model.ClassAnnotationMeta;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Engine responsible for analyzing a `.jar` file and extracting metadata about
 * class-level and method-level annotations.
 * <p>
 * The analysis is performed by dynamically loading classes from the given JAR
 * using a custom {@link URLClassLoader}, and using Java Reflection to inspect
 * class and method annotations.
 * </p>
 *
 * <h3>Responsibilities:</h3>
 * - Scan all `.class` files in the JAR
 * - Collect annotations on classes and their methods
 * - Return structured results as a list of {@link ClassAnnotationMeta}
 *
 * <h3>Design Principles:</h3>
 * - Single Responsibility: Only analyzes JAR contents
 * - Open/Closed: Extendable to support field-level annotations or additional metadata
 */
public class JarInsightEngine {

    /**
     * Scans the provided JAR file and analyzes each `.class` file to extract annotation metadata.
     *
     * @param jarPath Path to the JAR file to be scanned
     * @return List of {@link ClassAnnotationMeta} representing class and method annotations
     */
    public List<ClassAnnotationMeta> analyze(String jarPath) {
        List<ClassAnnotationMeta> results = new ArrayList<>();

        try (JarFile jar = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jar.entries(); // Get all entries in the JAR

            // Create a class loader pointing to the JAR file
            URL[] urls = {new File(jarPath).toURI().toURL()};
            try (URLClassLoader loader = new URLClassLoader(urls)) {

                // Iterate over each entry in the JAR
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();

                    // Process only `.class` files
                    if (entry.getName().endsWith(".class")) {
                        String className = entry.getName()
                                .replace("/", ".")       // Convert file path to package format
                                .replace(".class", "");  // Remove `.class` extension

                        try {
                            // Dynamically load the class
                            Class<?> clazz = loader.loadClass(className);

                            // Collect class-level annotations
                            List<String> classAnnotations = new ArrayList<>();
                            for (Annotation annotation : clazz.getAnnotations()) {
                                classAnnotations.add("@" + annotation.annotationType().getSimpleName());
                            }

                            // Collect method-level annotations
                            Map<String, List<String>> methodAnnotations = new LinkedHashMap<>();
                            for (Method method : clazz.getDeclaredMethods()) {
                                List<String> annotations = new ArrayList<>();
                                for (Annotation annotation : method.getAnnotations()) {
                                    annotations.add("@" + annotation.annotationType().getSimpleName());
                                }

                                // Only add methods with annotations
                                if (!annotations.isEmpty()) {
                                    methodAnnotations.put(method.getName(), annotations);
                                }
                            }

                            // Save results if any annotations were found
                            if (!classAnnotations.isEmpty() || !methodAnnotations.isEmpty()) {
                                results.add(new ClassAnnotationMeta(className, classAnnotations, methodAnnotations));
                            }

                        } catch (Throwable ignored) {
                            // Skip class if it fails to load (e.g., missing dependencies)
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("************     Failed to analyze JAR: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }
}

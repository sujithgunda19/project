package com.insight.analyzer.report;

import com.insight.analyzer.model.ClassAnnotationMeta;
import java.util.List;

/**
 * Strategy interface for writing annotation analysis reports in different formats.
 * <p>
 * Implementations of this interface are responsible for generating reports
 * (e.g., JSON, plain text) based on the analysis result produced by {@code JarInsightEngine}.
 * </p>
 *
 * <h3>Design Pattern:</h3>
 * - **Strategy Pattern**: Enables interchangeable report generation strategies
 * - **Open/Closed Principle**: New formats (e.g., HTML, XML) can be added without modifying existing code
 * - **Dependency Inversion Principle**: Consumers depend on the abstraction, not concrete classes
 *
 * <h3>Example Usage:</h3>
 * <pre>
 *     Reporter reporter = new JsonReporter();
 *     reporter.writeReport(classDataList);
 * </pre>
 */
public interface Reporter {

    /**
     * Writes the provided list of {@link ClassAnnotationMeta} objects to a report.
     *
     * @param data List containing metadata of scanned classes and their annotations.
     */
    void writeReport(List<ClassAnnotationMeta> data);
}

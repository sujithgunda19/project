package com.insight.analyzer.model;

import java.util.List;
import java.util.Map;

/**
 * Model class representing the annotation metadata of a class found within a JAR file.
 * <p>
 * This data structure captures:
 * <ul>
 *   <li>The fully qualified class name</li>
 *   <li>A list of class-level annotations</li>
 *   <li>A map of method names to their corresponding method-level annotations</li>
 * </ul>
 * </p>
 *
 * <h3>Usage:</h3>
 * Used by the {@code JarInsightEngine} to collect and return structured annotation data
 * which is later consumed by reporters such as {@code JsonReporter} or {@code PlainTextReporter}.
 *
 * <h3>Design Notes:</h3>
 * - Immutable fields for safety and predictability
 * - Constructor-based initialization
 * - Promotes separation of concerns by cleanly modeling parsed results
 */
public class ClassAnnotationMeta {

    /**
     * Fully qualified name of the class (e.g., com.example.MyService).
     */
    private final String className;

    /**
     * List of annotations applied directly on the class.
     */
    private final List<String> classAnnotations;

    /**
     * Map containing method names as keys and a list of their annotations as values.
     * <p>
     * Example:
     * <pre>
     *     "getUser" -> [@GetMapping, @Transactional]
     * </pre>
     * </p>
     */
    private final Map<String, List<String>> methodAnnotations;

    /**
     * Constructor to initialize all fields.
     *
     * @param className         Fully qualified class name.
     * @param classAnnotations  List of annotations present at the class level.
     * @param methodAnnotations Map of method names to their respective annotations.
     */
    public ClassAnnotationMeta(String className, List<String> classAnnotations, Map<String, List<String>> methodAnnotations) {
        this.className = className;
        this.classAnnotations = classAnnotations;
        this.methodAnnotations = methodAnnotations;
    }

    /**
     * Returns the name of the class.
     *
     * @return Fully qualified class name.
     */
    public String getClassName() {
        return className;
    }

    /**
     * Returns the list of class-level annotations.
     *
     * @return List of annotations applied to the class.
     */
    public List<String> getClassAnnotations() {
        return classAnnotations;
    }

    /**
     * Returns the method-level annotations as a map.
     *
     * @return Map of method names to lists of their annotations.
     */
    public Map<String, List<String>> getMethodAnnotations() {
        return methodAnnotations;
    }
}

package com.insight.analyzer.runner;

import java.io.File;
import java.util.List;

import com.insight.analyzer.config.AnalyzerConfigConstants;
import com.insight.analyzer.model.ClassAnnotationMeta;
import com.insight.analyzer.report.JsonReporter;
import com.insight.analyzer.report.PlainTextReporter;
import com.insight.analyzer.report.Reporter;
import com.insight.analyzer.scanner.JarInsightEngine;

/**
 * Entry point for the JAR Insight Analyzer application.
 * <p>
 * This runner accepts a path to a `.jar` file and an optional output format flag.
 * It analyzes the class and method-level annotations in the JAR and outputs the results
 * in either plain text or JSON format.
 * </p>
 *
 * <h2>Usage:</h2>
 * <pre>
 *     java -jar analyzer.jar path/to/jarfile.jar [--format=json|plain]
 * </pre>
 * 
 * <h3>Example:</h3>
 * <pre>
 *     java -jar analyzer.jar sample.jar --format=json
 * </pre>
 */
public class JarInsightRunner {

    /**
     * Main method — starts the application.
     *
     * @param args Command line arguments:
     *             args[0] = path to target JAR file
     *             args[1] = optional output format (--format=json or --format=plain)
     */
	 public static void main(String[] args) {
	        if (args.length < 1) {
	            printUsage();
	            System.exit(1);
	        }

	        String jarPath = args[0];
	        String format = args.length > 1 ? parseFormat(args[1]) : AnalyzerConfigConstants.DEFAULT_FORMAT;

	        try {
	            validateInputs(jarPath, format);
	            
	            File jarFile = new File(jarPath);
	            JarInsightEngine engine = new JarInsightEngine();
	            List<ClassAnnotationMeta> result = engine.analyze(jarFile.getAbsolutePath());

	            Reporter reporter = createReporter(format);
	            reporter.writeReport(result);
	            
	            System.exit(0);
	        } catch (IllegalArgumentException e) {
	            System.err.println("Error: " + e.getMessage());
	            printUsage();
	            System.exit(1);
	        } catch (Exception e) {
	            System.err.println("Unexpected error: " + e.getMessage());
	            e.printStackTrace();
	            System.exit(2);
	        }
	    }

	    private static void validateInputs(String jarPath, String format) {
	        File jarFile = new File(jarPath);
	        
	        if (!jarFile.exists()) {
	            throw new IllegalArgumentException("JAR file not found: " + jarPath);
	        }
	        if (!jarFile.canRead()) {
	            throw new IllegalArgumentException("Cannot read JAR file: " + jarPath);
	        }
	        if (jarFile.length() == 0) {
	            throw new IllegalArgumentException("JAR file is empty: " + jarPath);
	        }
	        if (!format.equalsIgnoreCase("json") && !format.equalsIgnoreCase("plain")) {
	            throw new IllegalArgumentException("Invalid format. Use 'json' or 'plain'");
	        }
	    }

	    private static String parseFormat(String formatArg) {
	        if (formatArg.startsWith("--format=")) {
	            return formatArg.split("=")[1];
	        }
	        return formatArg; // Assume it's just the format without prefix
	    }

	    private static Reporter createReporter(String format) {
	        return format.equalsIgnoreCase(AnalyzerConfigConstants.JSON_FORMAT)
	            ? new JsonReporter()
	            : new PlainTextReporter();
	    }

	    private static void printUsage() {
	        System.out.println("Usage:");
	        System.out.println("  java -jar jar-insight-analyzer.jar <path-to-jar> [format]");
	        System.out.println();
	        System.out.println("Arguments:");
	        System.out.println("  <path-to-jar>  Path to the JAR file to analyze (required)");
	        System.out.println("  [format]       Output format: json or plain (default: plain)");
	        System.out.println();
	        System.out.println("Examples:");
	        System.out.println("  java -jar jar-insight-analyzer.jar target/myapp.jar");
	        System.out.println("  java -jar jar-insight-analyzer.jar target/myapp.jar json");
	        System.out.println("  java -jar jar-insight-analyzer.jar target/myapp.jar --format=plain");
	    }

	
}

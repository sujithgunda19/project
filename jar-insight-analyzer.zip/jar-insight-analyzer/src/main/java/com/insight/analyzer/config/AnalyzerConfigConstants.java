package com.insight.analyzer.config;

/**
 * Configuration constants used throughout the JAR Insight Analyzer project.
 * <p>
 * This class defines default values and output filenames used for reporting.
 * It serves as a centralized location for constants to promote maintainability and readability.
 * </p>
 *
 * <h3>Usage:</h3>
 * These constants can be accessed statically from anywhere in the application:
 * <pre>
 *     String format = AnalyzerConfigConstants.DEFAULT_FORMAT;
 * </pre>
 *
 * <h3>Design:</h3>
 * - Final class members: all values are constants
 * - No need for object instantiation
 */
public class AnalyzerConfigConstants {

    /**
     * Default output format if none is specified.
     * Accepted values are "plain" or "json".
     */
    public static final String DEFAULT_FORMAT = "plain";

    /**
     * Output format key for JSON formatting.
     * Used in CLI option and reporter selection.
     */
    public static final String JSON_FORMAT = "json";

    /**
     * Output filename for plain text reports.
     * This file will be created in the root directory after analysis.
     */
    public static final String OUTPUT_FILE_TXT = "annotation-report.txt";

    /**
     * Output filename for JSON reports.
     * This file will be created in the root directory after analysis.
     */
    public static final String OUTPUT_FILE_JSON = "annotation-report.json";
}

package com.insight.analyzer.report;

import com.insight.analyzer.config.AnalyzerConfigConstants;
import com.insight.analyzer.model.ClassAnnotationMeta;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.util.List;

/**
 * Implementation of the {@link Reporter} interface that generates a report in JSON format.
 * <p>
 * This class uses Jackson's {@link ObjectMapper} to serialize a list of
 * {@link ClassAnnotationMeta} objects into a human-readable, indented JSON file.
 * </p>
 *
 * <h3>Output:</h3>
 * The file is written to the path specified by {@link AnalyzerConfigConstants#OUTPUT_FILE_JSON}.
 *
 * <h3>Design Principles:</h3>
 * - Follows Open/Closed Principle: new reporters can be added without modifying existing ones.
 * - Clean exception handling to ensure graceful failure.
 */
public class JsonReporter implements Reporter {

    /**
     * Writes the list of annotation metadata to a JSON file.
     *
     * @param data List of {@link ClassAnnotationMeta} objects to serialize.
     */
    @Override
    public void writeReport(List<ClassAnnotationMeta> data) {
        try {
            // Initialize Jackson's ObjectMapper for JSON serialization
            ObjectMapper mapper = new ObjectMapper();

            // Enable pretty-printing for better readability
            mapper.enable(SerializationFeature.INDENT_OUTPUT);

            // Serialize the data and write it to the JSON output file
            mapper.writeValue(new File(AnalyzerConfigConstants.OUTPUT_FILE_JSON), data);

            // Notify the user of success
            System.out.println("JSON Report written successfully to " + AnalyzerConfigConstants.OUTPUT_FILE_JSON);
        } catch (Exception e) {
            // Handle any exception and log a clean error message
            System.err.println(" Error while writting to JSON : " + e.getMessage());
        }
    }
}
